# Game & Watch: Manhole (MH-06) – Android

Emulador del Sharp SM5A con la ROM original `mh-06` (app/src/main/assets) y el
layout LCD `gnw_manholeg.svg` (cada segmento `x.y.z` = grupo O, bit, línea H),
portado del núcleo SM5A de MAME.

Controles: botones en pantalla (▲▼ izquierda/derecha, GAME A, GAME B, TIME, ALARM, ACL, sonido).
Teclado: W/S (izq. arriba/abajo), ↑/↓ (der.), 1 Game A, 2 Game B, 3 Time, 4 Alarm, R/Del = ACL.

## Compilar con GitHub
1. Sube el contenido de este ZIP al repositorio (incluida la carpeta `.github`), o sube el ZIP tal cual
   junto con `.github/workflows/build-apk.yml`.
2. Pestaña **Actions → Build APK** (se lanza solo con cada push).
3. Descarga el APK en *Artifacts → GnW-Manhole-APK*.
