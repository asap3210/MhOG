package com.gnw.manhole;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/** Draws the LCD (segments from the SVG) and the on-screen controls; handles multi-touch. */
public final class GameView extends View {
    // button ids
    static final int LUP = 0, LDOWN = 1, RUP = 2, RDOWN = 3, GAMEA = 4, GAMEB = 5, TIME = 6, ALARM = 7, ACL = 8, SOUND = 9, NB = 10;

    private final Sm5a emu;
    private final EmuRunner runner;
    private final float vbW, vbH;
    private final Path[][] segPaths;     // per segment: list of paths
    private final int[] segIndex;
    private final Paint onPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ghostPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint panelPaint = new Paint();
    private final Paint btnPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint btnLine = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint iconPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final RectF[] btn = new RectF[NB];
    private final boolean[] pressed = new boolean[NB];
    private final RectF lcd = new RectF();
    private float lcdScale = 1f;
    private int lastW = -1, lastH = -1;
    private final float dp;

    public GameView(Context ctx, Sm5a emu, EmuRunner runner, SvgSegments svg) {
        super(ctx);
        this.emu = emu;
        this.runner = runner;
        this.dp = ctx.getResources().getDisplayMetrics().density;
        vbW = svg.width;
        vbH = svg.height;
        int n = svg.segs.size();
        segPaths = new Path[n][];
        segIndex = new int[n];
        for (int i = 0; i < n; i++) {
            SvgSegments.Seg s = svg.segs.get(i);
            segIndex[i] = s.index();
            List<Path> ps = new ArrayList<>();
            for (String d : s.paths) {
                final Path p = new Path();
                SvgSegments.parsePath(d, new SvgSegments.PathSink() {
                    public void moveTo(float x, float y) { p.moveTo(x, y); }
                    public void lineTo(float x, float y) { p.lineTo(x, y); }
                    public void cubicTo(float a, float b, float c, float dd, float e, float f) { p.cubicTo(a, b, c, dd, e, f); }
                    public void close() { p.close(); }
                });
                ps.add(p);
            }
            segPaths[i] = ps.toArray(new Path[0]);
        }
        for (int i = 0; i < NB; i++) btn[i] = new RectF();
        // same look as the SVG: black segments at 0.847 opacity on white
        onPaint.setStyle(Paint.Style.FILL);
        onPaint.setColor(Color.argb(216, 0, 0, 0));
        ghostPaint.setStyle(Paint.Style.FILL);
        ghostPaint.setColor(Color.argb(14, 0, 0, 0));
        panelPaint.setColor(Color.WHITE);
        btnLine.setStyle(Paint.Style.STROKE);
        btnLine.setStrokeWidth(2f * dp);
        btnLine.setColor(0xFF6A6A6A);
        iconPaint.setStyle(Paint.Style.FILL);
        iconPaint.setColor(0xFFE8E8E8);
        textPaint.setColor(0xFFE8E8E8);
        textPaint.setTextAlign(Paint.Align.CENTER);
        textPaint.setFakeBoldText(true);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setBackgroundColor(0xFF161616);
    }

    // ---------------- redraw only when the LCD changes ----------------
    private final boolean[] lastSeg = new boolean[128];
    private boolean ticking;
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!ticking) return;
            final boolean[] cur = emu.seg;
            boolean diff = false;
            for (int i = 0; i < lastSeg.length; i++) {
                if (cur[i] != lastSeg[i]) { lastSeg[i] = cur[i]; diff = true; }
            }
            if (diff) invalidate();
            postOnAnimation(this);
        }
    };

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ticking = true;
        postOnAnimation(ticker);
    }

    @Override
    protected void onDetachedFromWindow() {
        ticking = false;
        removeCallbacks(ticker);
        super.onDetachedFromWindow();
    }

    // ---------------- layout ----------------
    private void layout(int w, int h) {
        float pad = 8f * dp;
        boolean land = w >= h;
        if (land) {
            float sideW = Math.min(w * 0.17f, h * 0.55f);
            float fnH = Math.min(h * 0.15f, 56f * dp);
            float availW = w - 2 * sideW - 2 * pad, availH = h - fnH - 3 * pad;
            lcdScale = Math.min(availW / vbW, availH / vbH);
            float lw = vbW * lcdScale, lh = vbH * lcdScale;
            float lx = sideW + pad + (availW - lw) / 2f, ly = pad + (availH - lh) / 2f;
            lcd.set(lx, ly, lx + lw, ly + lh);
            float colH = (h - 3 * pad) / 2f;
            btn[LUP].set(pad, pad, sideW, pad + colH);
            btn[LDOWN].set(pad, 2 * pad + colH, sideW, 2 * pad + 2 * colH);
            btn[RUP].set(w - sideW, pad, w - pad, pad + colH);
            btn[RDOWN].set(w - sideW, 2 * pad + colH, w - pad, 2 * pad + 2 * colH);
            fnRow(lx, ly + lh + pad, lw, fnH);
        } else {
            float lw = w - 2 * pad;
            lcdScale = lw / vbW;
            float lh = vbH * lcdScale;
            lcd.set(pad, pad, pad + lw, pad + lh);
            float fnH = Math.min(w * 0.13f, 60f * dp);
            fnRow(pad, pad + lh + pad, lw, fnH);
            float top = pad + lh + pad + fnH + pad * 2;
            float bh = Math.max(40f * dp, (h - top - 2 * pad - pad) / 2f);
            float half = (w - 3 * pad) / 2f;
            btn[LUP].set(pad, top, pad + half, top + bh);
            btn[LDOWN].set(pad, top + bh + pad, pad + half, top + 2 * bh + pad);
            btn[RUP].set(2 * pad + half, top, w - pad, top + bh);
            btn[RDOWN].set(2 * pad + half, top + bh + pad, w - pad, top + 2 * bh + pad);
        }
    }

    private void fnRow(float x, float y, float w, float h) {
        int[] order = {GAMEA, GAMEB, TIME, ALARM, ACL, SOUND};
        float gap = 6f * dp;
        float bw = (w - gap * (order.length - 1)) / order.length;
        for (int i = 0; i < order.length; i++) {
            float bx = x + i * (bw + gap);
            btn[order[i]].set(bx, y, bx + bw, y + h);
        }
    }

    // ---------------- drawing ----------------
    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w != lastW || h != lastH) { lastW = w; lastH = h; layout(w, h); }

        c.drawRect(lcd, panelPaint);
        c.save();
        c.translate(lcd.left, lcd.top);
        c.scale(lcdScale, lcdScale);
        final boolean[] seg = emu.seg;
        for (int i = 0; i < segPaths.length; i++) {
            Paint p = seg[segIndex[i]] ? onPaint : ghostPaint;
            for (Path path : segPaths[i]) c.drawPath(path, p);
        }
        c.restore();

        for (int i = 0; i < NB; i++) drawButton(c, i);
    }

    private static final String[] LABELS = {null, null, null, null, "GAME A", "GAME B", "TIME", "ALARM", "ACL", null};

    private void drawButton(Canvas c, int i) {
        RectF r = btn[i];
        boolean on = pressed[i] || (i == SOUND && runner.isMuted());
        btnPaint.setStyle(Paint.Style.FILL);
        btnPaint.setColor(on ? 0xFF5A5A5A : 0xFF2C2C2C);
        float rad = 12f * dp;
        c.drawRoundRect(r, rad, rad, btnPaint);
        c.drawRoundRect(r, rad, rad, btnLine);
        float cx = r.centerX(), cy = r.centerY();
        if (i <= RDOWN) {
            float s = Math.min(r.width(), r.height()) * 0.22f;
            Path t = new Path();
            if (i == LUP || i == RUP) { t.moveTo(cx, cy - s); t.lineTo(cx + s * 1.2f, cy + s * 0.8f); t.lineTo(cx - s * 1.2f, cy + s * 0.8f); }
            else { t.moveTo(cx, cy + s); t.lineTo(cx + s * 1.2f, cy - s * 0.8f); t.lineTo(cx - s * 1.2f, cy - s * 0.8f); }
            t.close();
            c.drawPath(t, iconPaint);
        } else if (i == SOUND) {
            float s = r.height() * 0.2f;
            Path t = new Path();
            t.moveTo(cx - s * 1.4f, cy - s * 0.6f); t.lineTo(cx - s * 0.5f, cy - s * 0.6f); t.lineTo(cx + s * 0.6f, cy - s * 1.4f);
            t.lineTo(cx + s * 0.6f, cy + s * 1.4f); t.lineTo(cx - s * 0.5f, cy + s * 0.6f); t.lineTo(cx - s * 1.4f, cy + s * 0.6f); t.close();
            c.drawPath(t, iconPaint);
            if (runner.isMuted()) {
                btnLine.setColor(0xFFFF5555);
                c.drawLine(cx - s * 1.6f, cy + s * 1.6f, cx + s * 1.6f, cy - s * 1.6f, btnLine);
                btnLine.setColor(0xFF6A6A6A);
            }
        } else {
            textPaint.setTextSize(Math.min(r.height() * 0.32f, r.width() * 0.22f));
            c.drawText(LABELS[i], cx, cy + textPaint.getTextSize() * 0.35f, textPaint);
        }
    }

    // ---------------- touch ----------------
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        boolean[] now = new boolean[NB];
        int skip = (action == MotionEvent.ACTION_POINTER_UP) ? e.getActionIndex() : -1;
        if (action != MotionEvent.ACTION_UP && action != MotionEvent.ACTION_CANCEL) {
            for (int p = 0; p < e.getPointerCount(); p++) {
                if (p == skip) continue;
                float x = e.getX(p), y = e.getY(p);
                int b = hit(x, y);
                if (b >= 0) now[b] = true;
            }
        }
        applyButtons(now);
        invalidate();
        return true;
    }

    private int hit(float x, float y) {
        float slop = 6f * dp;
        int best = -1;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i < NB; i++) {
            RectF r = btn[i];
            if (x >= r.left - slop && x <= r.right + slop && y >= r.top - slop && y <= r.bottom + slop) {
                float dx = x - r.centerX(), dy = y - r.centerY();
                float d = dx * dx + dy * dy;
                if (d < bestD) { bestD = d; best = i; }
            }
        }
        return best;
    }

    private void applyButtons(boolean[] now) {
        if (now[SOUND] && !pressed[SOUND]) runner.setMuted(!runner.isMuted());
        System.arraycopy(now, 0, pressed, 0, NB);
        int in1 = 0, in2 = 0;
        if (now[RDOWN]) in1 |= 0x01;
        if (now[RUP]) in1 |= 0x02;
        if (now[LDOWN]) in1 |= 0x04;
        if (now[LUP]) in1 |= 0x08;
        if (now[TIME]) in2 |= 0x01;
        if (now[GAMEB]) in2 |= 0x02;
        if (now[GAMEA]) in2 |= 0x04;
        if (now[ALARM]) in2 |= 0x08;
        emu.in1 = in1;
        emu.in2 = in2;
        emu.updateKLine();
        emu.setAcl(now[ACL]);
    }

    // ---------------- keyboard (physical keyboards / gamepads) ----------------
    private static int keyToButton(int code) {
        switch (code) {
            case android.view.KeyEvent.KEYCODE_W: case android.view.KeyEvent.KEYCODE_Q: return LUP;
            case android.view.KeyEvent.KEYCODE_S: case android.view.KeyEvent.KEYCODE_A: return LDOWN;
            case android.view.KeyEvent.KEYCODE_DPAD_UP: case android.view.KeyEvent.KEYCODE_P: return RUP;
            case android.view.KeyEvent.KEYCODE_DPAD_DOWN: case android.view.KeyEvent.KEYCODE_L: return RDOWN;
            case android.view.KeyEvent.KEYCODE_1: case android.view.KeyEvent.KEYCODE_BUTTON_START: return GAMEA;
            case android.view.KeyEvent.KEYCODE_2: case android.view.KeyEvent.KEYCODE_BUTTON_SELECT: return GAMEB;
            case android.view.KeyEvent.KEYCODE_3: return TIME;
            case android.view.KeyEvent.KEYCODE_4: return ALARM;
            case android.view.KeyEvent.KEYCODE_DEL: case android.view.KeyEvent.KEYCODE_R: return ACL;
            default: return -1;
        }
    }

    private boolean key(int code, boolean down) {
        int b = keyToButton(code);
        if (b < 0) return false;
        boolean[] now = pressed.clone();
        now[b] = down;
        applyButtons(now);
        invalidate();
        return true;
    }

    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        return key(keyCode, true) || super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        return key(keyCode, false) || super.onKeyUp(keyCode, event);
    }
}
