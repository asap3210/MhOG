package com.gnw.manhole;

import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

/** Runs the SM5A in real time. Paced by AudioTrack writes (32768 Hz = one sample per oscillator tick). */
public final class EmuRunner implements Runnable {
    private static final int CHUNK = 1024; // ticks (~31 ms)
    private final Sm5a emu;
    private volatile boolean running;
    private volatile boolean muted;
    private Thread thread;

    public EmuRunner(Sm5a emu) { this.emu = emu; }

    public void setMuted(boolean m) { muted = m; }
    public boolean isMuted() { return muted; }

    public void start() {
        if (thread != null) return;
        running = true;
        thread = new Thread(this, "sm5a-emu");
        thread.setPriority(Thread.MAX_PRIORITY);
        thread.start();
    }

    public void stop() {
        running = false;
        if (thread != null) {
            try { thread.join(1000); } catch (InterruptedException ignored) { }
            thread = null;
        }
    }

    @Override
    public void run() {
        AudioTrack track = null;
        try {
            int min = AudioTrack.getMinBufferSize(Sm5a.CLOCK, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(Sm5a.CLOCK)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(min, CHUNK * 2 * 3))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
            track.play();
        } catch (Throwable t) {
            track = null;
        }

        short[] buf = new short[CHUNK];
        final short hi = 5200, lo = -5200;
        long next = System.nanoTime();
        while (running) {
            short h = muted ? 0 : hi, l = muted ? 0 : lo;
            emu.run(CHUNK, buf, 0, h, l);
            boolean paced = false;
            if (track != null) {
                int w = track.write(buf, 0, CHUNK); // blocking => real-time pacing
                paced = w >= 0;
                if (!paced) { try { track.release(); } catch (Throwable ignored) { } track = null; }
            }
            if (!paced) {
                next += (long) (1e9 * CHUNK / Sm5a.CLOCK);
                long sleep = next - System.nanoTime();
                if (sleep > 0) {
                    try { Thread.sleep(sleep / 1000000L, (int) (sleep % 1000000L)); } catch (InterruptedException e) { break; }
                } else if (sleep < -200_000_000L) {
                    next = System.nanoTime();
                }
            }
        }
        if (track != null) {
            try { track.pause(); track.flush(); track.release(); } catch (Throwable ignored) { }
        }
    }
}
