package com.gnw.manhole;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public final class MainActivity extends Activity {
    private static Sm5a emu; // survives activity re-creation
    private EmuRunner runner;
    private GameView view;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        try {
            AssetManager am = getAssets();
            if (emu == null) emu = new Sm5a(readAll(am, "mh-06"));
            SvgSegments svg = SvgSegments.parse(new String(readAll(am, "gnw_manholeg.svg"), "UTF-8"));
            runner = new EmuRunner(emu);
            view = new GameView(this, emu, runner, svg);
            setContentView(view);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static byte[] readAll(AssetManager am, String name) throws Exception {
        try (InputStream in = am.open(name)) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersive();
        runner.start();
    }

    @Override
    protected void onPause() {
        runner.stop();
        // release any held inputs
        emu.in1 = 0; emu.in2 = 0; emu.updateKLine(); emu.setAcl(false);
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) immersive();
    }

    @SuppressWarnings("deprecation")
    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
