package com.gnw.manhole;

/**
 * Sharp SM5A core + Game & Watch (hh_sm510 "gnw_manholeg") machine glue.
 * Port of MAME's sm510/sm500/sm5a cores (BSD-3-Clause, hap) for the MH-06 ROM.
 *
 * Time base: 32768 Hz oscillator ticks. CPU runs one machine cycle every 2 ticks.
 */
public final class Sm5a {
    public static final int CLOCK = 32768;

    // ---- ROM / RAM ----
    private final byte[] rom = new byte[0x800];
    private final int[] ram = new int[0x80];

    // ---- CPU state ----
    private int pc, prevPc, op, prevOp, param;
    private final int[] stack = new int[4];
    private int acc, bl, bm, c;
    private boolean skip, halt, extWakeup;
    private int r, rOut;
    private int div, gamma;
    private int bp;
    private int mx, cb, s;
    private boolean rsub;
    private final int[] ox = new int[9];
    private final int[] o = new int[9];
    private static final int O_PINS = 9;

    // ---- machine / inputs ----
    private int inpMux;
    /** IN.0 (R2), IN.1 (R3), IN.2 (R4) bit masks, set by the UI. */
    public volatile int in0, in1, in2;
    private volatile boolean cheatBa = true; // BA=1 => cheat off
    private boolean aclHeld;

    // ---- outputs ----
    private int speaker;          // current piezo level (0/1)
    private int lcdTickAcc;       // ticks until next 1 kHz lcd/decay tick
    private static final int LCD_PERIOD = 0x20;

    // lcd decay (hh_sm510 deflicker). index = (o<<1 | h), bit y
    private final int[] displayState = new int[0x20];
    private final int[][] decay = new int[4][0x20];
    private static final int DECAY_PIVOT = 8, DECAY_LEN = 17;
    /** Output segments x.y.z flattened: [(x*4+y)*2+z]. Written by emulator thread, read by UI. */
    public final boolean[] seg = new boolean[16 * 4 * 2];


    public Sm5a(byte[] romData) {
        System.arraycopy(romData, 0, rom, 0, Math.min(romData.length, 0x740));
        powerOn();
    }

    // ================= memory =================
    private int readProg(int addr) {
        addr &= 0x7ff;
        if (addr < 0x700) return rom[addr] & 0xff;
        return rom[0x700 | (addr & 0x3f)] & 0xff;
    }

    private static int dataIndex(int a) {
        a &= 0x7f;
        int row = a >> 4, n = a & 0xf;
        if (n > 0xc) n = 0xc;
        if (row > 4) row = 4;
        return row << 4 | n;
    }

    private int ramR() {
        return ram[dataIndex(bm << 4 | bl)] & 0xf;
    }

    private void ramW(int v) {
        ram[dataIndex(bm << 4 | bl)] = v & 0xf;
    }

    // ================= power / reset =================
    private void powerOn() {
        // device_start: everything zero
        pc = prevPc = op = prevOp = param = 0;
        acc = bl = bm = c = 0;
        skip = false; halt = false; extWakeup = false;
        r = rOut = 0; div = 0; gamma = 0; bp = 0;
        mx = cb = s = 0; rsub = false;
        java.util.Arrays.fill(stack, 0);
        java.util.Arrays.fill(ox, 0);
        java.util.Arrays.fill(o, 0);
        java.util.Arrays.fill(ram, 0);
        inpMux = 0; speaker = 0; lcdTickAcc = 0;
        java.util.Arrays.fill(displayState, 0);
        for (int[] d : decay) java.util.Arrays.fill(d, 0);
        reset();
    }

    /** device_reset (ACL release). RAM is preserved as in MAME. */
    public void reset() {
        skip = false; halt = false;
        op = prevOp = 0;
        doBranch(0, 0xf, 0);
        prevPc = pc;
        bp = 1;
        r = rOut = 0;
        writeR(0);
        // SM500 specific
        pushStack();
        opIdiv();
        gamma = 1;
        cb = 0;
        rsub = false;
        r = 0xf;
    }

    public synchronized void setAcl(boolean pressed) {
        if (aclHeld && !pressed) reset();
        aclHeld = pressed;
    }


    // ================= I/O =================
    private int readK() {
        int ret = 0;
        if ((inpMux & 1) != 0) ret |= in0;
        if ((inpMux & 2) != 0) ret |= in1;
        if ((inpMux & 4) != 0) ret |= in2;
        return ret & 0xf;
    }

    /** Must be called by the UI after changing in0/in1/in2 (input_changed). */
    public synchronized void updateKLine() {
        extWakeup = readK() != 0;
    }

    private void writeR(int data) {
        speaker = data & 1;
        inpMux = (data >> 1) & 0xf;
        extWakeup = readK() != 0;
    }

    public int speakerLevel() { return speaker; }

    private void clockMelody() {
        int out = (1 & ~r) | (~r & 0xe);
        out &= 0xf;
        if (out != rOut) {
            writeR(out);
            rOut = out;
        }
    }

    // ================= LCD =================
    private void lcdUpdate() {
        for (int h = 0; h < 2; h++) {
            for (int oo = 0; oo < O_PINS; oo++) {
                int sg = h != 0 ? ox[oo] : o[oo];
                displayState[oo << 1 | h] = (bp & 1) != 0 ? sg : 0;
            }
        }
    }

    private void displayDecayTick() {
        for (int zx = 0; zx < 0x20; zx++) {
            for (int y = 0; y < 4; y++) {
                if ((displayState[zx] >> y & 1) != 0) {
                    if (decay[y][zx] < DECAY_PIVOT + DECAY_LEN) decay[y][zx]++;
                } else if (decay[y][zx] > 0) {
                    decay[y][zx]--;
                }
                boolean on = decay[y][zx] >= DECAY_PIVOT;
                int x = zx >> 1, z = zx & 1;
                if (x < 16) seg[(x * 4 + y) * 2 + z] = on;
            }
        }
    }

    // ================= timing =================
    private void tick() {
        // divider timer @ 32768 Hz
        div = (div + 1) & 0x7fff;
        if (div == 0) gamma |= 1;
        clockMelody();
        if (++lcdTickAcc >= LCD_PERIOD) {
            lcdTickAcc = 0;
            lcdUpdate();
            displayDecayTick();
        }
    }

    /**
     * Run the machine for n oscillator ticks, writing the piezo level at each tick into out
     * (out may be null). One CPU cycle = 2 ticks.
     */
    public synchronized void run(int ticks, short[] out, int outOff, short hi, short lo) {
        int t = 0;
        while (t < ticks) {
            if (pending == 0) {
                int cyc;
                if (aclHeld) {
                    cyc = 1; // CPU held in reset
                } else if (halt) {
                    if (extWakeup || gamma != 0) doInterrupt();
                    cyc = 1;
                } else {
                    cyc = step();
                }
                pending = cyc * 2;
            }
            while (pending > 0 && t < ticks) {
                tick();
                pending--;
                if (out != null) out[outOff + t] = speaker != 0 ? hi : lo;
                t++;
            }
        }
    }

    private int pending; // ticks left of the instruction currently "executing"

    // ================= execute =================
    private void doInterrupt() {
        halt = false;
        // wakeup_vector
        cb = 0;
        doBranch(0, 0, 0);
    }

    private void incrementPc() {
        int pagemask = 0x3f;
        int msb = (pagemask >> 1) ^ pagemask;
        int feed = (((pc >> 1) ^ pc) & 1) != 0 ? 0 : msb;
        pc = feed | (pc >> 1 & pagemask >> 1) | (pc & ~pagemask);
        pc &= 0x7ff;
    }

    private int step() {
        int cycles = 1;
        prevOp = op;
        prevPc = pc;
        op = readProg(pc);
        incrementPc();
        if (op == 0x5e || op == 0x5f) {
            cycles++;
            param = readProg(pc);
            incrementPc();
        }
        if (skip) {
            skip = false;
            op = 0;
        } else {
            executeOne();
        }
        return cycles;
    }

    private void doBranch(int pu, int pm, int pl) {
        pc = ((pu << 10) | (pm << 6 & 0x3c0) | (pl & 0x3f)) & 0x7ff;
    }

    private void pushStack() { stack[0] = pc; }

    private void popStack() { pc = stack[0] & 0x7ff; }

    private void executeOne() {
        switch (op & 0xf0) {
            case 0x20: opLax(); return;
            case 0x30: opAdx(); return;
            case 0x40: opLb(); return;
            case 0x70: stack[0] = (stack[0] & ~0x3c0) | ((op & 0xf) << 6 & 0x3c0); return; // SSR
            case 0x80: case 0x90: case 0xa0: case 0xb0: opTr(); return;
            case 0xc0: case 0xd0: case 0xe0: case 0xf0: opTrs(); return;
            default: break;
        }
        switch (op & 0xfc) {
            case 0x04: ramW(ramR() & ~(1 << (op & 3))); return;            // RM
            case 0x0c: ramW(ramR() | (1 << (op & 3))); return;             // SM
            case 0x10: opExc(); return;                                     // EXC
            case 0x14: opExc(); opIncb(); return;                           // EXCI
            case 0x18: acc = ramR(); bm ^= (op & 3); return;                // LDA
            case 0x1c: opExc(); opDecb(); return;                           // EXCD
            case 0x54: skip = (ramR() & (1 << (op & 3))) != 0; return;      // TMI
            default: break;
        }
        switch (op) {
            case 0x00: return;                                    // SKIP
            case 0x01: r = acc; clockMelody(); return;            // ATR
            case 0x02: bm |= 4; return;                           // SBM
            case 0x03: bp = acc; return;                          // ATBP
            case 0x08: acc = (acc + ramR()) & 0xf; return;        // ADD
            case 0x09: {                                          // ADD11
                acc += ramR() + c;
                c = acc >> 4 & 1;
                skip = (c == 1);
                acc &= 0xf;
                return;
            }
            case 0x0a: acc ^= 0xf; return;                        // COMA
            case 0x0b: { int a = acc; acc = bl; bl = a; return; } // EXBLA

            case 0x50: skip = cheatBa; return;                    // TAL (BA pin)
            case 0x51: skip = true; return;                       // TB (B pin = 1)
            case 0x52: skip = (c == 0); return;                   // TC
            case 0x53: skip = (acc == ramR()); return;            // TAM
            case 0x58: skip = (gamma == 0); gamma = 0; return;    // TIS
            case 0x59: o[O_PINS - 1] = ox[O_PINS - 1]; o[O_PINS - 2] = ox[O_PINS - 2]; return; // PTW
            case 0x5a: skip = (acc == 0); return;                 // TA0
            case 0x5b: skip = (acc == bl); return;                // TABL
            case 0x5c: System.arraycopy(ox, 0, o, 0, O_PINS); return; // TW
            case 0x5d: shiftW(); ox[O_PINS - 1] = getDigit(); return; // DTW
            case 0x5f: bl = param & 0xf; bm = (param & 0x7f) >> 4; return; // LBL

            case 0x60: bp ^= 8; return;                           // COMCN
            case 0x61: ox[O_PINS - 2] = ox[O_PINS - 1]; ox[O_PINS - 1] = getDigit(); return; // PDTW
            case 0x62: shiftW(); ox[O_PINS - 1] = acc & 7; return;   // WR
            case 0x63: shiftW(); ox[O_PINS - 1] = acc | 8; return;  // WS
            case 0x64: opIncb(); return;                          // INCB
            case 0x65: opIdiv(); return;                          // IDIV
            case 0x66: c = 0; return;                             // RC
            case 0x67: c = 1; return;                             // SC
            case 0x68: mx = 0; acc = 0; return;                   // RMF
            case 0x69: mx = 1; return;                            // SMF
            case 0x6a: acc = readK() & 0xf; return;               // KTA
            case 0x6b: bm &= ~4; return;                          // RBM
            case 0x6c: opDecb(); return;                          // DECB
            case 0x6d: cb ^= 1; return;                           // COMCB
            case 0x6e: popStack(); rsub = false; return;          // RTN0
            case 0x6f: popStack(); rsub = false; skip = true; return; // RTN1

            case 0x5e:
                op = op << 8 | param;
                switch (param) {
                    case 0x00: halt = true; return;               // CEND
                    case 0x04: acc = div >> 11 & 0xf; return;     // DTA
                    default: return;                              // illegal
                }
            default: return; // illegal
        }
    }

    private void shiftW() {
        for (int i = 0; i < O_PINS - 1; i++) ox[i] = ox[i + 1];
    }

    private static final int[] LUT_DIGITS = {
        0xe, 0x0, 0xc, 0x8, 0x2, 0xa, 0xe, 0x2, 0xe, 0xa, 0x0, 0x0, 0x2, 0xa, 0x2, 0x2,
        0xb, 0x9, 0x7, 0xf, 0xd, 0xe, 0xe, 0xb, 0xf, 0xf, 0x4, 0x0, 0xd, 0xe, 0x4, 0x0
    };

    private int getDigit() {
        int sel = bp >> 3 & 1;
        return (LUT_DIGITS[sel << 4 | acc] | (~sel & mx)) & 0xff;
    }

    private void opLax() {
        if ((op & ~0xf) != (prevOp & ~0xf)) acc = op & 0xf;
    }

    private void opAdx() {
        acc += (op & 0xf);
        skip = ((op & 0xf) != 10 && (acc & 0x10) != 0);
        acc &= 0xf;
    }

    private void opLb() {
        bm = op & 3;
        bl = (op >> 2 & 3) | ((op & 0xc) != 0 ? 8 : 0);
    }

    private void opExc() {
        int a = acc;
        acc = ramR();
        ramW(a);
        bm ^= (op & 3);
    }

    private void opIncb() {
        bl = (bl + 1) & 0xf;
        skip = (bl == 8);
    }

    private void opDecb() {
        bl = (bl - 1) & 0xf;
        skip = (bl == 0xf);
    }

    private void opIdiv() {
        div &= 0x3f;
    }

    private void opTr() {
        pc = (pc & ~0x3f) | (op & 0x3f);
        if (!rsub) doBranch(cb, suGet(), pc & 0x3f);
    }

    private int suGet() { return stack[0] >> 6 & 0xf; }

    private void opTrs() {
        if (!rsub) {
            rsub = true;
            int su = suGet();
            pushStack();
            doBranch(1, 0, op & 0x3f);
            if ((prevOp & 0xf0) == 0x70) doBranch(cb, su, pc & 0x3f);
        } else {
            pc = (pc & ~0xff) | (op << 2 & 0xc0) | (op & 0xf);
        }
    }
}
