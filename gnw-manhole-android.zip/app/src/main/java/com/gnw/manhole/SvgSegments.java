package com.gnw.manhole;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the MAME-style segment SVG: every segment is a group with a title "x.y.z"
 * (x = O group, y = segment bit, z = H line) containing one or more paths.
 * Pure Java so it can be tested on a plain JVM.
 */
public final class SvgSegments {
    public interface PathSink {
        void moveTo(float x, float y);
        void lineTo(float x, float y);
        void cubicTo(float x1, float y1, float x2, float y2, float x, float y);
        void close();
    }

    public static final class Seg {
        public final int x, y, z;
        public final List<String> paths = new ArrayList<>();
        Seg(int x, int y, int z) { this.x = x; this.y = y; this.z = z; }
        public int index() { return (x * 4 + y) * 2 + z; }
    }

    public float width = 3266f, height = 2116f;
    public final List<Seg> segs = new ArrayList<>();

    private static final Pattern VIEWBOX = Pattern.compile("viewBox=\"\\s*([-\\d.eE]+)[ ,]+([-\\d.eE]+)[ ,]+([-\\d.eE]+)[ ,]+([-\\d.eE]+)\\s*\"");
    private static final Pattern GROUP = Pattern.compile("<g\\b[^>]*>((?:(?!<g\\b|</g>).)*)</g>", Pattern.DOTALL);
    private static final Pattern TITLE = Pattern.compile("<title[^>]*>\\s*(\\d+)\\.(\\d+)\\.(\\d+)\\s*</title>");
    private static final Pattern PATH_D = Pattern.compile("<path\\b[^>]*?\\sd=\"([^\"]*)\"", Pattern.DOTALL);

    public static SvgSegments parse(String svg) {
        SvgSegments r = new SvgSegments();
        Matcher vb = VIEWBOX.matcher(svg);
        if (vb.find()) {
            r.width = Float.parseFloat(vb.group(3));
            r.height = Float.parseFloat(vb.group(4));
        }
        Matcher g = GROUP.matcher(svg);
        while (g.find()) {
            String body = g.group(1);
            Matcher t = TITLE.matcher(body);
            if (!t.find()) continue;
            int x = Integer.parseInt(t.group(1)), y = Integer.parseInt(t.group(2)), z = Integer.parseInt(t.group(3));
            if (x >= 16 || y >= 4 || z >= 2) continue;
            Seg s = new Seg(x, y, z);
            Matcher p = PATH_D.matcher(body);
            while (p.find()) s.paths.add(p.group(1));
            if (!s.paths.isEmpty()) r.segs.add(s);
        }
        return r;
    }

    // ---------------- SVG path data -> sink ----------------
    private static int pos;

    public static synchronized void parsePath(String d, PathSink sink) {
        final int n = d.length();
        pos = 0;
        char cmd = 0;
        float cx = 0, cy = 0, sx = 0, sy = 0;
        while (true) {
            skipSep(d, n);
            if (pos >= n) break;
            char ch = d.charAt(pos);
            if (Character.isLetter(ch)) {
                cmd = ch;
                pos++;
                if (cmd == 'z' || cmd == 'Z') {
                    sink.close();
                    cx = sx; cy = sy;
                    continue;
                }
            } else if (cmd == 0) {
                break; // garbage
            }
            switch (cmd) {
                case 'M': case 'm': {
                    float x = num(d, n), y = num(d, n);
                    if (cmd == 'm') { x += cx; y += cy; }
                    cx = x; cy = y; sx = x; sy = y;
                    sink.moveTo(x, y);
                    cmd = (cmd == 'M') ? 'L' : 'l';
                    break;
                }
                case 'L': case 'l': {
                    float x = num(d, n), y = num(d, n);
                    if (cmd == 'l') { x += cx; y += cy; }
                    cx = x; cy = y;
                    sink.lineTo(x, y);
                    break;
                }
                case 'H': case 'h': {
                    float x = num(d, n);
                    if (cmd == 'h') x += cx;
                    cx = x;
                    sink.lineTo(cx, cy);
                    break;
                }
                case 'V': case 'v': {
                    float y = num(d, n);
                    if (cmd == 'v') y += cy;
                    cy = y;
                    sink.lineTo(cx, cy);
                    break;
                }
                case 'C': case 'c': {
                    float x1 = num(d, n), y1 = num(d, n), x2 = num(d, n), y2 = num(d, n), x = num(d, n), y = num(d, n);
                    if (cmd == 'c') { x1 += cx; y1 += cy; x2 += cx; y2 += cy; x += cx; y += cy; }
                    sink.cubicTo(x1, y1, x2, y2, x, y);
                    cx = x; cy = y;
                    break;
                }
                default:
                    return; // unsupported command in this file set
            }
        }
    }

    private static void skipSep(String d, int n) {
        while (pos < n) {
            char c = d.charAt(pos);
            if (c == ' ' || c == ',' || c == '\n' || c == '\r' || c == '\t') pos++;
            else break;
        }
    }

    private static float num(String d, int n) {
        skipSep(d, n);
        int st = pos;
        if (pos < n && (d.charAt(pos) == '-' || d.charAt(pos) == '+')) pos++;
        boolean dot = false;
        while (pos < n) {
            char c = d.charAt(pos);
            if (c >= '0' && c <= '9') pos++;
            else if (c == '.' && !dot) { dot = true; pos++; }
            else break;
        }
        if (pos < n && (d.charAt(pos) == 'e' || d.charAt(pos) == 'E')) {
            pos++;
            if (pos < n && (d.charAt(pos) == '-' || d.charAt(pos) == '+')) pos++;
            while (pos < n && Character.isDigit(d.charAt(pos))) pos++;
        }
        if (st == pos) { pos = n; return 0f; }
        return Float.parseFloat(d.substring(st, pos));
    }
}
